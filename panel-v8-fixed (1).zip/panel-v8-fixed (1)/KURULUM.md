# 🚀 VENUE PANEL v8 — KURULUM KILAVUZU
## Sorunlar neydi, nasıl düzeltildi

---

## ❌ V7'DEKİ HATALAR (Teşhis)

### Hata 1 — ANON KEY SAHTE (Ana Sebep)
```js
// supabase.js satır 8 — YANLIŞ
const SUPABASE_ANON_KEY = 'sb_publishable_XXXXXXXXXXXXXXX';
```
Bu sahte bir key. Supabase bağlantısı hiç kurulamadı.
Veri sadece PC'de görünüyordu çünkü hata yakalanmayınca STATE içinde kalıyordu.

### Hata 2 — DUPLICATE CONST (JavaScript Crash)
```js
const SUPABASE_URL = '...';
const SUPABASE_URL = '...'; // İKİ KEZ — JavaScript hata verir!
```

### Hata 3 — TANIMLANMAYAN NESNELER
`app.js` şu nesneleri kullanıyor ama `supabase.js`'te tanımlı değildi:
- `AylikOzet` → ✅ Eklendi
- `KonserKalemler` → ✅ Eklendi
- `Ayarlar` → ✅ Eklendi
- `Yedek` → ✅ Eklendi
- `OtomatikYedek` → ✅ Eklendi
- `Export` → ✅ Eklendi

### Hata 4 — RLS SADECE AUTHENTICATED İÇİN
Kullanıcı giriş yapmadan önce veri çekmeye çalışırken RLS engelliyordu.
✅ `anon` kullanıcılara da erişim eklendi.

---

## ✅ KURULUM ADIMLARI

### Adım 1 — Supabase Projenizi Hazırlayın

1. [supabase.com](https://supabase.com) → Projenize girin
2. Sol menü → **SQL Editor**
3. `schema.sql` içeriğini kopyalayıp yapıştırın → **RUN**
4. Yeşil "Success" görmelisiniz

> ⚠️ Eğer daha önce schema çalıştırdıysanız:
> `DROP TABLE IF EXISTS tablo_adı CASCADE;` ile eski tabloları silip tekrar çalıştırın.
> Ya da sadece RLS policy'leri ekleyin:
> ```sql
> CREATE POLICY "anon_all" ON gunluk_satis FOR ALL TO anon USING (true) WITH CHECK (true);
> -- (Her tablo için tekrarlayın)
> ```

### Adım 2 — API Bilgilerini Alın

1. Supabase → **Settings → API**
2. Kopyalayın:
   - **Project URL**: `https://XXXX.supabase.co`
   - **anon / public key**: `eyJ...` ile başlayan uzun anahtar

### Adım 3 — supabase.js Dosyasını Düzenleyin

```js
// supabase.js — SADECE BU İKİ SATIRI DEĞİŞTİRİN
const SUPABASE_URL = 'https://BURAYA_PROJECT_ID.supabase.co';
const SUPABASE_ANON_KEY = 'eyJBURAYA_GERCEK_ANON_KEY_YAZIN';
```

> ⚠️ ANON KEY mutlaka `eyJ` ile başlar ve çok uzundur (~200 karakter).
> `sb_publishable_xxx` formatında değildir!

### Adım 4 — Kullanıcı Oluşturun

1. Supabase → **Authentication → Users**
2. **Add user** → E-posta + Şifre girin
3. "Auto Confirm User" işaretli olsun

### Adım 5 — GitHub Pages'e Yükleyin

1. GitHub'da repo oluşturun (public veya private)
2. 3 dosyayı yükleyin: `index.html`, `supabase.js`, `app.js`
3. Settings → Pages → Branch: main → `/` (root) → Save
4. Birkaç dakika bekleyin → `https://kullaniciad.github.io/repo-adi/`

### Adım 6 — Supabase'de GitHub Pages URL'ini Ekleyin

1. Supabase → **Settings → API → CORS**
2. Veya **Authentication → URL Configuration**
3. **Site URL**: `https://kullaniciad.github.io/repo-adi`
4. **Redirect URLs**: Aynı URL + `/**`

---

## 🧪 TEST ETME

1. GitHub Pages URL'ini Chrome'da açın
2. Supabase kullanıcı e-posta/şifresini girin
3. Günlük Satış → bir kayıt girin → Kaydet
4. Supabase → **Table Editor → gunluk_satis** → kaydı görmelisiniz ✅
5. Aynı URL'yi telefonda açın → aynı veri görünmeli ✅

---

## 🆘 SORUN GİDERME

| Hata | Sebep | Çözüm |
|------|-------|-------|
| Giriş olmuyor | Yanlış email/şifre | Supabase → Auth → Users'dan kontrol edin |
| "Failed to fetch" | URL veya KEY yanlış | supabase.js'i kontrol edin |
| Veri kaydedilmiyor | RLS politikası yok | schema.sql'i yeniden çalıştırın |
| Telefonda görünmüyor | CORS hatası | Supabase → Settings → CORS'a URL ekleyin |
| "TypeError: X is not a function" | script sırası yanlış | index.html: önce supabase.js, sonra app.js |

---

## 📁 DOSYA YAPISI

```
repo/
├── index.html    → Tüm panel HTML + CSS
├── supabase.js   → DB bağlantısı + tüm DB nesneleri
├── app.js        → Uygulama mantığı (değiştirme)
├── schema.sql    → Supabase tabloları (bir kere çalıştır)
└── KURULUM.md    → Bu dosya
```

---

## 🔑 ÖNEMLİ NOTLAR

- **localStorage hiç kullanılmıyor** — tüm veri Supabase'de
- **Şifre Supabase Auth'ta** — panel içi şifre yok
- **Her cihaz aynı veriyi görür** — gerçek zamanlı senkronizasyon
- **GitHub Pages çalışır** — statik dosya, sunucu gerektirmiyor
