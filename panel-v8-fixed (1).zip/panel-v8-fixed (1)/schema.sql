-- ============================================
-- VENUE PANEL — CLEAN SUPABASE SCHEMA
-- Supabase > SQL Editor > tamamını çalıştır
-- ============================================

-- Extensions
create extension if not exists pgcrypto;

-- ============================================
-- TABLOLAR
-- ============================================

create table if not exists public.gunluk_satis (
  id uuid primary key default gen_random_uuid(),
  tarih date not null,
  ciro numeric(12,2) not null default 0,
  nakit numeric(12,2) not null default 0,
  pos numeric(12,2) not null default 0,
  bira numeric(12,2) not null default 0,
  alkol numeric(12,2) not null default 0,
  alkolsuz numeric(12,2) not null default 0,
  yiyecek numeric(12,2) not null default 0,
  cerez numeric(12,2) not null default 0,
  bilet numeric(12,2) not null default 0,
  urun_maliyet numeric(12,2) not null default 0,
  ikram_maliyet numeric(12,2) not null default 0,
  not_alani text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.konserler (
  id uuid primary key default gen_random_uuid(),
  tip integer not null default 1,
  sanatci text not null,
  tarih date not null,
  durum text not null default 'Planlandı',
  not_alani text not null default '',
  bilet_adet integer not null default 0,
  bilet_fiyat numeric(12,2) not null default 0,
  bar_ciro numeric(12,2) not null default 0,
  bilet_ciro numeric(12,2) not null default 0,
  sponsor numeric(12,2) not null default 0,
  diger_gelir numeric(12,2) not null default 0,
  destek_tutari numeric(12,2) not null default 0,
  kase numeric(12,2) not null default 0,
  konser_diger_gider numeric(12,2) not null default 0,
  ekipman numeric(12,2) not null default 0,
  guvenlik numeric(12,2) not null default 0,
  ekstra_personel numeric(12,2) not null default 0,
  kadrolu_personel numeric(12,2) not null default 0,
  ikram_maliyet numeric(12,2) not null default 0,
  urun_maliyet numeric(12,2) not null default 0,
  bilet_maliyet numeric(12,2) not null default 0,
  reklam numeric(12,2) not null default 0,
  ulasim numeric(12,2) not null default 0,
  diger_gider numeric(12,2) not null default 0,
  toplam_gelir numeric(12,2) not null default 0,
  toplam_gider numeric(12,2) not null default 0,
  net_kar numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.urunler (
  id uuid primary key default gen_random_uuid(),
  ad text not null,
  kategori text not null default 'Diğer',
  satis_fiyati numeric(12,2) not null default 0,
  maliyet numeric(12,2) not null default 0,
  aylik_adet integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.aylik_ozet (
  id uuid primary key default gen_random_uuid(),
  ay integer not null check (ay between 0 and 11),
  yil integer not null,
  ciro numeric(12,2) not null default 0,
  urun_maliyet numeric(12,2) not null default 0,
  ikram_maliyet numeric(12,2) not null default 0,
  diger_giderler numeric(12,2) not null default 0,
  toplam_gider numeric(12,2) not null default 0,
  brut_kar numeric(12,2) not null default 0,
  net_kar numeric(12,2) not null default 0,
  brut_marj numeric(8,4) not null default 0,
  net_marj numeric(8,4) not null default 0,
  gider_detay jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint aylik_ozet_ay_yil_unique unique (ay, yil)
);

create table if not exists public.giderler (
  id uuid primary key default gen_random_uuid(),
  tarih date not null,
  kategori text not null,
  aciklama text not null default '',
  tutar numeric(12,2) not null default 0,
  odeme_yontemi text not null default 'Nakit',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.personel (
  id uuid primary key default gen_random_uuid(),
  ad_soyad text not null,
  pozisyon text not null default 'Diğer',
  tur text not null default 'Kadrolu',
  aylik_maas numeric(12,2) not null default 0,
  sgk numeric(12,2) not null default 0,
  telefon text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ayarlar (
  id uuid primary key default gen_random_uuid(),
  anahtar text not null unique,
  deger jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.konser_kalemler (
  id uuid primary key default gen_random_uuid(),
  etiket text not null unique,
  sira integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================
-- UPDATED_AT TRIGGER
-- ============================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_gunluk_satis_updated_at on public.gunluk_satis;
create trigger trg_gunluk_satis_updated_at
before update on public.gunluk_satis
for each row
execute function public.set_updated_at();

drop trigger if exists trg_konserler_updated_at on public.konserler;
create trigger trg_konserler_updated_at
before update on public.konserler
for each row
execute function public.set_updated_at();

drop trigger if exists trg_urunler_updated_at on public.urunler;
create trigger trg_urunler_updated_at
before update on public.urunler
for each row
execute function public.set_updated_at();

drop trigger if exists trg_aylik_ozet_updated_at on public.aylik_ozet;
create trigger trg_aylik_ozet_updated_at
before update on public.aylik_ozet
for each row
execute function public.set_updated_at();

drop trigger if exists trg_giderler_updated_at on public.giderler;
create trigger trg_giderler_updated_at
before update on public.giderler
for each row
execute function public.set_updated_at();

drop trigger if exists trg_personel_updated_at on public.personel;
create trigger trg_personel_updated_at
before update on public.personel
for each row
execute function public.set_updated_at();

drop trigger if exists trg_ayarlar_updated_at on public.ayarlar;
create trigger trg_ayarlar_updated_at
before update on public.ayarlar
for each row
execute function public.set_updated_at();

drop trigger if exists trg_konser_kalemler_updated_at on public.konser_kalemler;
create trigger trg_konser_kalemler_updated_at
before update on public.konser_kalemler
for each row
execute function public.set_updated_at();

-- ============================================
-- VARSAYILAN VERİLER
-- ============================================

insert into public.konser_kalemler (etiket, sira)
values
  ('Sanatçı Kaşesi', 1),
  ('Konser Diğer Gider (Yemek, Otel vs.)', 2),
  ('Ekipman', 3),
  ('Müzisyen', 4),
  ('Güvenlik Personel', 5),
  ('Gelen Ekstra Personel', 6),
  ('Kadrolu Personel', 7),
  ('Reklam / Tanıtım', 8),
  ('Uçak', 9),
  ('Otel', 10),
  ('Diğer Masraflar', 11)
on conflict (etiket) do nothing;

-- ============================================
-- RLS
-- NOT: Bu yapı anon erişime açık.
-- Yani gerçek anon key bilen erişebilir.
-- Test / geçici kurulum için uygundur.
-- Daha güvenli yapı istersek sonra auth'a çeviririz.
-- ============================================

alter table public.gunluk_satis enable row level security;
alter table public.konserler enable row level security;
alter table public.urunler enable row level security;
alter table public.aylik_ozet enable row level security;
alter table public.giderler enable row level security;
alter table public.personel enable row level security;
alter table public.ayarlar enable row level security;
alter table public.konser_kalemler enable row level security;

drop policy if exists gunluk_satis_anon_all on public.gunluk_satis;
create policy gunluk_satis_anon_all
on public.gunluk_satis
for all
to anon
using (true)
with check (true);

drop policy if exists gunluk_satis_auth_all on public.gunluk_satis;
create policy gunluk_satis_auth_all
on public.gunluk_satis
for all
to authenticated
using (true)
with check (true);

drop policy if exists konserler_anon_all on public.konserler;
create policy konserler_anon_all
on public.konserler
for all
to anon
using (true)
with check (true);

drop policy if exists konserler_auth_all on public.konserler;
create policy konserler_auth_all
on public.konserler
for all
to authenticated
using (true)
with check (true);

drop policy if exists urunler_anon_all on public.urunler;
create policy urunler_anon_all
on public.urunler
for all
to anon
using (true)
with check (true);

drop policy if exists urunler_auth_all on public.urunler;
create policy urunler_auth_all
on public.urunler
for all
to authenticated
using (true)
with check (true);

drop policy if exists aylik_ozet_anon_all on public.aylik_ozet;
create policy aylik_ozet_anon_all
on public.aylik_ozet
for all
to anon
using (true)
with check (true);

drop policy if exists aylik_ozet_auth_all on public.aylik_ozet;
create policy aylik_ozet_auth_all
on public.aylik_ozet
for all
to authenticated
using (true)
with check (true);

drop policy if exists giderler_anon_all on public.giderler;
create policy giderler_anon_all
on public.giderler
for all
to anon
using (true)
with check (true);

drop policy if exists giderler_auth_all on public.giderler;
create policy giderler_auth_all
on public.giderler
for all
to authenticated
using (true)
with check (true);

drop policy if exists personel_anon_all on public.personel;
create policy personel_anon_all
on public.personel
for all
to anon
using (true)
with check (true);

drop policy if exists personel_auth_all on public.personel;
create policy personel_auth_all
on public.personel
for all
to authenticated
using (true)
with check (true);

drop policy if exists ayarlar_anon_all on public.ayarlar;
create policy ayarlar_anon_all
on public.ayarlar
for all
to anon
using (true)
with check (true);

drop policy if exists ayarlar_auth_all on public.ayarlar;
create policy ayarlar_auth_all
on public.ayarlar
for all
to authenticated
using (true)
with check (true);

drop policy if exists konser_kalemler_anon_all on public.konser_kalemler;
create policy konser_kalemler_anon_all
on public.konser_kalemler
for all
to anon
using (true)
with check (true);

drop policy if exists konser_kalemler_auth_all on public.konser_kalemler;
create policy konser_kalemler_auth_all
on public.konser_kalemler
for all
to authenticated
using (true)
with check (true);